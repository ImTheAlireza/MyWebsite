/**
 * Alireza Shabanzadeh — 2026 Motion Portfolio Preview
 * Interactive Fake Data, Bilingual (EN/FA) Switcher, Theme Toggle & Native Dialogs
 */

(function () {
  'use strict';

  // ==========================================================================
  // 1. BILINGUAL DICTIONARY (EN & FA)
  // ==========================================================================
  const I18N = {
    en: {
      skipLink: 'Skip to content',
      siteName: 'Alireza Shabanzadeh',
      navWork: 'Work',
      navServices: 'Services',
      navProcess: 'Process',
      navAbout: 'About',
      navRates: 'Rates',
      navContact: 'Contact',
      navCta: 'Start a project',
      langToggleLabel: 'فارسی',

      heroAvailability: 'Capacity: 20–30 hours / month',
      heroEyebrow: 'Motion Designer · Product & UI Motion',
      heroFirstName: 'Alireza',
      heroLastName: 'Shabanzadeh',
      heroSubtitle: '2D & UI motion for product and learning teams. Turning complex software workflows and educational concepts into crisp, purposeful motion.',
      heroCtaPrimary: 'See selected work',
      heroShowreelBtn: 'Watch 60s Showreel',
      heroCtaSecondary: 'Send a brief',
      heroPromise: 'Tell me the goal and deadline; I’ll reply with a clear scope, price and timeline.',
      pauseReel: 'Pause reel',
      playReel: 'Play reel',
      expandReel: 'Full Reel',

      stat1Value: '8+ Years',
      stat1Label: 'Motion design · 5 yrs in university e-learning',
      stat2Value: 'Rasht, Iran',
      stat2Label: 'UTC+3:30 · Async-first collaboration',
      stat3Value: '20–30 hrs',
      stat3Label: 'Monthly dedicated studio capacity',

      workKicker: '01 // PORTFOLIO & CASE STUDIES',
      workTitle: 'Selected Work',
      workIntro: 'Selected product motion, 2D explainers and e-learning visual systems. Explore by client brand or filter individual case studies with real outcomes.',
      filterAll: 'All Work',
      filterBrands: 'Client Brands',
      filterUi: 'Product & UI Motion',
      filterExplainer: '2D Explainer & Learning',

      servicesKicker: '02 // WHAT I DO',
      servicesTitle: 'Services & Deliverables',
      servicesIntro: 'Product and UI motion first, followed by 2D explainers and structured educational content for university and SaaS teams.',
      service1Title: 'Product & UI Motion',
      service1Desc: 'High-clarity interface animations, feature launch videos, onboarding walkthroughs, and micro-interaction prototypes that show users how your product works without overwhelming them.',
      s1Item1: 'SaaS Product Walkthroughs & Launch Reels',
      s1Item2: 'UI Component Transitions & State Motion',
      s1Item3: '4K MP4 / WebM Loops Ready for Landing Pages',
      service2Title: '2D Explainer & Learning Content',
      service2Desc: 'Structured 2D explainers, visual metaphors, and course graphics built on 5+ years of university e-learning production experience. Designed for retention and pedagogical clarity.',
      s2Item1: '2D Narrative Explainers & Storyboarded Visuals',
      s2Item2: 'University & Corporate E-Learning Modules',
      s2Item3: 'Synced Voiceover, Captions & Multi-Ratio Exports',

      processKicker: '03 // WORKFLOW',
      processTitle: 'How I Work',
      processIntro: 'Calm, asynchronous, and written-first. No unnecessary meetings—just clear milestones from brief to final render.',
      processBadge1: 'Async Brief',
      process1Title: 'Send a written brief',
      process1Desc: 'Share your goal, target audience, existing assets (slides, script, or UI screens) and deadline via email or the form below. A live call is never required by default.',
      processBadge2: 'Fixed Scope',
      process2Title: 'Agree scope, price & timeline',
      process2Desc: 'Within 24 hours, I reply with a concrete deliverable list, fixed price or hourly estimate, and a milestone schedule so everyone knows what to expect before work begins.',
      processBadge3: 'Iterative Delivery',
      process3Title: 'Motion & written review',
      process3Desc: 'We review styleframes, animatics, and motion passes asynchronously with timestamped written feedback, delivering clean master files on schedule.',

      aboutKicker: '04 // PROFILE & BACKGROUND',
      aboutTitle: 'About & Toolkit',
      aboutIntro: 'Combining a Software Engineering background with 8 years of motion craft and 5 years in academic e-learning.',
      aboutLocationBadge: 'Rasht, Iran · UTC+3:30',
      bioEyebrow: 'THE DESIGNER',
      aboutP1: 'I’m a motion designer based in Rasht, Iran. I have eight years of experience in motion design, including five years creating e-learning content for a university.',
      aboutP2: 'My academic background is in Software Engineering, and my current focus is product/UI motion, 2D explainers and educational visuals. Because I understand how interfaces and code are structured, I translate complex technical products into clear visual stories with minimal hand-holding.',
      toolsLabel: 'PRIMARY TOOLKIT & PIPELINE',
      levelAdvanced: 'Advanced · Expressions & 2D Rigging',
      levelAdvancedPs: 'Advanced · Styleframes & Assets',
      levelProPr: 'Editing, Sound & Mastering',
      levelBasicAi: 'Vector Asset Prep',
      levelBasicBl: 'Basic 3D Elements',

      expHeading: 'Professional Experience',
      tagCurrent: 'Current',
      exp1Date: 'June 2023 — Present',
      exp1Title: 'Motion Designer',
      exp1Org: 'IDmelon / Rahavard Samanehaye Amn',
      exp1Desc: 'Leading product and UI motion, hardware security key explainers, and enterprise passwordless authentication walkthroughs.',
      exp2Date: 'September 2018 — June 2023',
      exp2Title: 'E-learning Content Creator',
      exp2Org: 'Mehr-e-Alborz University',
      exp2Desc: 'Produced hundreds of minutes of structured academic e-learning modules, instructional graphics, and visual explainers for graduate courses.',
      exp3Date: 'January — August 2022',
      exp3Title: 'Motion Graphics Designer & Animator',
      exp3Org: 'Micfava',
      exp3Desc: 'Created 2D promotional explainers, character-driven educational clips, and social media motion assets.',

      eduHeading: 'Academic Education',
      tagAcademic: 'M.A.',
      edu1Date: '2024 — Present',
      edu1Title: 'M.A. in English Language Education',
      edu1Org: 'Azad University of Rasht',
      edu1Desc: 'Focusing on instructional design, bilingual communication, and multimedia learning principles.',
      edu2Date: '2022 — 2024',
      edu2Title: 'B.Sc. in Software Engineering',
      edu2Org: 'Shahid Chamran Technical University of Rasht',
      edu2Desc: 'Software architecture, human-computer interaction, and web technologies.',
      edu3Date: '2020 — 2022',
      edu3Title: 'Associate Degree in Software Engineering',
      edu3Org: 'Technical University of Chamran',
      edu3Desc: 'Foundations of programming, algorithms, and digital systems.',

      ratesKicker: '05 // TRANSPARENT PRICING',
      ratesTitle: 'Rates & Availability',
      ratesIntro: 'Clear ballpark numbers so you can gauge fit immediately. Every project receives a fixed quote after reviewing your written brief.',
      rate1Type: '2D EXPLAINER / LEARNING VIDEO',
      rate1Price: '$150–250',
      rate1Unit: 'per finished minute',
      rate1Note: 'Includes visual concepting, styleframes, 2D motion, and two structured revision rounds based on your script.',
      rateFeaturedBadge: 'MOST REQUESTED',
      rate2Type: 'UI & PRODUCT MOTION',
      rate2Price: '$25–35',
      rate2Unit: 'per hour (or fixed per clip)',
      rate2Note: 'Ideal for SaaS feature launches, abstract UI walkthroughs, onboarding loops, and design system motion guidelines.',
      rate3Type: 'MONTHLY STUDIO CAPACITY',
      rate3Price: '20–30 hrs',
      rate3Unit: 'available per month',
      rate3Note: 'Reliable recurring bandwidth for product or e-learning teams needing ongoing motion releases without hiring full-time.',

      contactKicker: '06 // COLLABORATE',
      contactTitle: 'Start a Project',
      contactIntro: 'Share the goal and deadline in a short written brief. I’ll reply within 24 hours with a scope, price and timeline.',
      formNameLabel: 'Your name',
      formNamePlaceholder: 'Alex Rivera',
      formEmailLabel: 'Email address',
      formEmailPlaceholder: 'alex@company.com',
      formTypeLabel: 'Project type',
      optionalText: '(optional)',
      optUi: 'Product / UI motion',
      optExplainer: '2D explainer / learning video',
      optRetainer: 'Monthly motion support (20–30h)',
      optOther: 'Not sure yet / Something else',
      formDeadlineLabel: 'Target deadline',
      formDeadlinePlaceholder: 'e.g. Late November, or flexible',
      formBriefLabel: 'The written brief',
      formBriefPlaceholder: 'What should the motion explain or show? Who is it for, and what assets do you already have (script, Figma UI, slides)?',
      formPrivacyNote: '* Required fields. Your details are only used to reply to your inquiry.',
      formSubmitBtn: 'Send the brief',
      directContactTitle: 'DIRECT CONTACT',
      copyBtn: 'Copy',
      copiedToast: 'Copied hello@alirezashabanzadeh.ir to clipboard!',
      locationLabel: 'Location & Timezone',
      locationValue: 'Rasht, Iran · UTC+3:30',
      responseLabel: 'Typical Response',
      responseValue: 'Within 1 business day',
      asyncTitle: 'WRITTEN & ASYNCHRONOUS',
      asyncCopy: 'I do my best work with clear written briefs and asynchronous feedback. Send a quick note with your goal and timeline—no discovery call needed to get a quote.',
      footerCopy: '© 2026 Alireza Shabanzadeh',
      footerNote: 'Motion Designer · Rasht, Iran · UTC+3:30',
      backToBrand: 'Back to brand',
      showreelModalTitle: 'Alireza Shabanzadeh — Motion Showreel',
      ctaCardTitle: 'Your project next?',
      ctaCardSub: 'Tell me what the motion needs to explain—get a clear scope, price and timeline back.',
      ctaCardAction: 'Send the brief',
      whyMattersLabel: 'WHY IT MATTERS & IMPACT',
      clientLabel: 'Client',
      deliverableLabel: 'Deliverable',
      roleLabel: 'Role',
      toolsUsedLabel: 'Tools Used',
      galleryItemsLabel: 'Gallery Items'
    },

    fa: {
      skipLink: 'رفتن به محتوای اصلی',
      siteName: 'علیرضا شابان‌زاده',
      navWork: 'نمونه‌کارها',
      navServices: 'خدمات',
      navProcess: 'شیوهٔ کار',
      navAbout: 'دربارهٔ من',
      navRates: 'تعرفه‌ها',
      navContact: 'تماس',
      navCta: 'شروع پروژه',
      langToggleLabel: 'English',

      heroAvailability: 'ظرفیت کاری: ۲۰ تا ۳۰ ساعت در ماه',
      heroEyebrow: 'طراح موشن · موشن محصول و رابط کاربری',
      heroFirstName: 'علیرضا',
      heroLastName: 'شابان‌زاده',
      heroSubtitle: 'موشن دوبعدی و رابط کاربری برای تیم‌های محصول و آموزشی. تبدیل جریان‌های پیچیدهٔ نرم‌افزاری و مفاهیم آموزشی به تصویر متحرک شفاف و هدفمند.',
      heroCtaPrimary: 'دیدن نمونه‌کارها',
      heroShowreelBtn: 'تماشای شوریل ۶۰ ثانیه‌ای',
      heroCtaSecondary: 'ارسال بریف',
      heroPromise: 'هدف و مهلت پروژه را بفرستید؛ با شرح کار، قیمت و زمان‌بندی دقیق پاسخ می‌دهم.',
      pauseReel: 'توقف ریل',
      playReel: 'پخش ریل',
      expandReel: 'نمایش کامل',

      stat1Value: '+۸ سال',
      stat1Label: 'سابقه در موشن دیزاین · ۵ سال در آموزش الکترونیکی دانشگاهی',
      stat2Value: 'رشت، ایران',
      stat2Label: 'UTC+3:30 · همکاری غیرهم‌زمان و مکتوب',
      stat3Value: '۲۰ تا ۳۰ ساعت',
      stat3Label: 'ظرفیت اختصاصی ماهانه برای پروژه‌ها',

      workKicker: '۰۱ // پورتفولیو و مطالعات موردی',
      workTitle: 'گزیدهٔ نمونه‌کارها',
      workIntro: 'گزیده‌ای از پروژه‌های موشن محصول، اکسپلینر دوبعدی و محتوای آموزشی. می‌توانید بر اساس برند کارفرما یا نوع پروژه فیلتر کنید و جزئیات هر کار را ببینید.',
      filterAll: 'همهٔ کارها',
      filterBrands: 'برندهای کارفرما',
      filterUi: 'موشن محصول و UI',
      filterExplainer: 'اکسپلینر دوبعدی و آموزشی',

      servicesKicker: '۰۲ // خدمات من',
      servicesTitle: 'خدمات و خروجی‌ها',
      servicesIntro: 'اولویت اول موشن محصول و رابط کاربری است؛ در کنار تولید اکسپلینرهای دوبعدی و محتوای آموزشی ساختارمند برای تیم‌های محصول و دانشگاهی.',
      service1Title: 'موشن محصول و رابط کاربری (UI)',
      service1Desc: 'انیمیشن‌های رابط کاربری با وضوح بالا، ویدیوهای معرفی فیچرهای جدید، راهنمای آنبوردینگ و پروتوتایپ‌های تعاملی که نحوهٔ کارکرد محصول شما را بدون پیچیدگی نمایش می‌دهند.',
      s1Item1: 'ویدیوهای معرفی محصول SaaS و دموی فیچرها',
      s1Item2: 'انیمیشن وضعیت کامپوننت‌ها و تعاملات رابط کاربری',
      s1Item3: 'خروجی‌های سبک 4K MP4 / WebM آماده برای لندینگ‌پیج',
      service2Title: 'اکسپلینر دوبعدی و محتوای آموزشی',
      service2Desc: 'ویدیوهای اکسپلینر دوبعدی، استعاره‌های تصویری و گرافیک‌های آموزشی بر پایهٔ ۵ سال تجربهٔ تولید محتوای الکترونیکی دانشگاهی؛ طراحی‌شده برای یادگیری عمیق و ماندگار.',
      s2Item1: 'اکسپلینرهای داستانی دوبعدی و استوری‌بوردینگ',
      s2Item2: 'ماژول‌های آموزش الکترونیکی دانشگاهی و سازمانی',
      s2Item3: 'هماهنگ‌سازی نریشن، زیرنویس و خروجی در ابعاد مختلف',

      processKicker: '۰۳ // روند همکاری',
      processTitle: 'شیوهٔ همکاری',
      processIntro: 'آرام، غیرهم‌زمان و مبتنی بر مکاتبهٔ شفاف. بدون جلسات غیرضروری؛ با مراحل مشخص از دریافت بریف تا تحویل فایل نهایی.',
      processBadge1: 'بریف مکتوب',
      process1Title: 'ارسال بریف مکتوب',
      process1Desc: 'هدف، مخاطب، فایل‌های موجود (اسلاید، متن یا طرح Figma) و ددلاین را از طریق فرم یا ایمیل بفرستید. به‌طور پیش‌فرض نیازی به تماس تلفنی نیست.',
      processBadge2: 'توافق شفاف',
      process2Title: 'توافق بر سر شرح کار، قیمت و زمان',
      process2Desc: 'حداکثر تا ۲۴ ساعت، فهرست دقیق خروجی‌ها، برآورد هزینه و زمان‌بندی مراحل را برایتان ارسال می‌کنم تا پیش از شروع همه‌چیز روشن باشد.',
      processBadge3: 'تحویل مرحله‌ای',
      process3Title: 'تولید موشن و بازبینی مکتوب',
      process3Desc: 'استایل‌فریم‌ها، انیماتیک و نسخه‌های موشن را مرحله‌به‌مرحله با بازخوردهای مکتوب و دقیق پیش می‌بریم تا فایل نهایی سر موعد تحویل شود.',

      aboutKicker: '۰۴ // معرفی و پیشینه',
      aboutTitle: 'دربارهٔ من و ابزارها',
      aboutIntro: 'ترکیب پیشینهٔ تحصیلی مهندسی نرم‌افزار با ۸ سال تجربهٔ موشن دیزاین و ۵ سال تولید محتوای آموزش الکترونیکی.',
      aboutLocationBadge: 'رشت، ایران · UTC+3:30',
      bioEyebrow: 'دربارهٔ طراح',
      aboutP1: 'من طراح موشن و ساکن رشت هستم. هشت سال سابقهٔ فعالیت حرفه‌ای در موشن دیزاین دارم که پنج سال آن صرف تولید محتوای آموزش الکترونیکی برای دانشگاه شده است.',
      aboutP2: 'پیشینهٔ تحصیلی من مهندسی نرم‌افزار است و تمرکز فعلی‌ام روی موشن محصول و رابط کاربری، اکسپلینر دوبعدی و محتوای بصری آموزشی است. آشنایی با منطق نرم‌افزار و رابط کاربری کمک می‌کند محصولات فنی را سریع‌تر درک کنم و به زبان تصویر برگردانم.',
      toolsLabel: 'ابزارهای اصلی و پایپ‌لاین تولید',
      levelAdvanced: 'پیشرفته · کدنویسی Expression و ریگ دوبعدی',
      levelAdvancedPs: 'پیشرفته · طراحی استایل‌فریم و دارایی‌ها',
      levelProPr: 'تدوین، صداگذاری و مسترینگ نهایی',
      levelBasicAi: 'آماده‌سازی المان‌های وکتور',
      levelBasicBl: 'المان‌های پایهٔ سه‌بعدی',

      expHeading: 'سوابق کاری حرفه‌ای',
      tagCurrent: 'همکاری فعلی',
      exp1Date: 'خرداد ۱۴۰۲ — اکنون',
      exp1Title: 'طراح موشن (Motion Designer)',
      exp1Org: 'IDmelon / رهاورد سامانه‌های امن',
      exp1Desc: 'طراحی و اجرای موشن محصول و رابط کاربری، ویدیوهای معرفی کلیدهای امنیتی و راهنماهای احراز هویت بدون رمز عبور.',
      exp2Date: 'شهریور ۱۳۹۷ — خرداد ۱۴۰۲',
      exp2Title: 'تولیدکنندهٔ محتوای آموزش الکترونیکی',
      exp2Org: 'دانشگاه مهرالبرز',
      exp2Desc: 'تولید صدها دقیقه محتوای آموزشی ساختارمند، اینفوگرافیک‌های متحرک و ویدیوهای درسی برای دوره‌های تحصیلات تکمیلی.',
      exp3Date: 'دی ۱۴۰۰ — مرداد ۱۴۰۱',
      exp3Title: 'طراح و انیماتور موشن گرافیک',
      exp3Org: 'میکفاوا (Micfava)',
      exp3Desc: 'ساخت اکسپلینرهای تبلیغاتی دوبعدی، کلیپ‌های آموزشی کاراکتری و موشن‌های شبکه‌های اجتماعی.',

      eduHeading: 'سوابق تحصیلی دانشگاهی',
      tagAcademic: 'ارشد',
      edu1Date: '۱۴۰۳ — اکنون',
      edu1Title: 'کارشناسی ارشد آموزش زبان انگلیسی',
      edu1Org: 'دانشگاه آزاد اسلامی واحد رشت',
      edu1Desc: 'تمرکز بر طراحی آموزشی، ارتباطات دوزبانه و اصول یادگیری چندرسانه‌ای.',
      edu2Date: '۱۴۰۱ — ۱۴۰۳',
      edu2Title: 'کارشناسی مهندسی نرم‌افزار',
      edu2Org: 'دانشگاه فنی و حرفه‌ای شهید چمران رشت',
      edu2Desc: 'معماری نرم‌افزار، تعامل انسان و کامپیوتر (HCI) و فناوری‌های وب.',
      edu3Date: '۱۳۹۹ — ۱۴۰۱',
      edu3Title: 'کاردانی مهندسی نرم‌افزار',
      edu3Org: 'دانشکده فنی شهید چمران رشت',
      edu3Desc: 'مبانی برنامه‌نویسی، الگوریتم‌ها و سیستم‌های دیجیتال.',

      ratesKicker: '۰۵ // شفافیت مالی',
      ratesTitle: 'تعرفه‌ها و ظرفیت کاری',
      ratesIntro: 'حدود قیمت‌ها به‌صورت شفاف درج شده تا پیش از ارسال پیام بتوانید تناسب بودجه را بسنجید. قیمت قطعی پس از بررسی بریف اعلام می‌شود.',
      rate1Type: 'ویدیوی اکسپلینر دوبعدی / آموزشی',
      rate1Price: '$150–250',
      rate1Unit: 'به ازای هر دقیقهٔ نهایی',
      rate1Note: 'شامل ایده‌پردازی بصری، طراحی استایل‌فریم، انیمیت دوبعدی و دو نوبت اصلاحیهٔ ساختارمند بر اساس سناریوی شما.',
      rateFeaturedBadge: 'پرتقاضاترین خدمت',
      rate2Type: 'موشن رابط کاربری و محصول (UI)',
      rate2Price: '$25–35',
      rate2Unit: 'ساعتی (یا مقطوع به ازای هر کلیپ)',
      rate2Note: 'مناسب برای معرفی فیچرهای SaaS، نمایش انتزاعی رابط کاربری، لوپ‌های آنبوردینگ و مستندسازی موشن دیزاین سیستم.',
      rate3Type: 'ظرفیت کاری ماهانه استودیو',
      rate3Price: '۲۰ تا ۳۰ ساعت',
      rate3Unit: 'ظرفیت آزاد در ماه',
      rate3Note: 'همکاری مستمر و قابل اتکا برای تیم‌های محصول یا آموزشی که به تولید ماهانهٔ موشن نیاز دارند.',

      contactKicker: '۰۶ // شروع همکاری',
      contactTitle: 'ارسال بریف پروژه',
      contactIntro: 'هدف و زمان‌بندی مدنظرتان را در قالب یک پیام کوتاه بنویسید. ظرف ۲۴ ساعت با شرح کار، قیمت و زمان‌بندی پاسخ می‌دهم.',
      formNameLabel: 'نام شما',
      formNamePlaceholder: 'مثلاً: آرش کریمی',
      formEmailLabel: 'نشانی ایمیل',
      formEmailPlaceholder: 'you@company.com',
      formTypeLabel: 'نوع پروژه',
      optionalText: '(اختیاری)',
      optUi: 'موشن محصول و رابط کاربری (UI)',
      optExplainer: 'اکسپلینر دوبعدی / ویدیوی آموزشی',
      optRetainer: 'همکاری ماهانه (۲۰ تا ۳۰ ساعت)',
      optOther: 'هنوز مطمئن نیستم / مورد دیگر',
      formDeadlineLabel: 'مهلت تحویل مدنظر',
      formDeadlinePlaceholder: 'مثلاً: اواسط آذر، یا بدون عجله',
      formBriefLabel: 'شرح مختصر پروژه (بریف)',
      formBriefPlaceholder: 'این ویدیو قرار است چه چیزی را توضیح دهد یا نمایش دهد؟ مخاطبش کیست و چه فایل‌هایی (متن، طرح Figma، اسلاید) آماده دارید؟',
      formPrivacyNote: '* فیلدهای ستاره‌دار الزامی هستند. اطلاعات شما صرفاً برای پاسخ به همین درخواست استفاده می‌شود.',
      formSubmitBtn: 'ارسال بریف پروژه',
      directContactTitle: 'ارتباط مستقیم',
      copyBtn: 'کپی ایمیل',
      copiedToast: 'نشانی ایمیل با موفقیت کپی شد!',
      locationLabel: 'موقعیت و منطقهٔ زمانی',
      locationValue: 'رشت، ایران · UTC+3:30',
      responseLabel: 'زمان پاسخ‌گویی معمول',
      responseValue: 'کمتر از ۱ روز کاری',
      asyncTitle: 'همکاری مکتوب و غیرهم‌زمان',
      asyncCopy: 'بهترین خروجی من زمانی شکل می‌گیرد که بریف و بازخوردها مکتوب و شفاف باشند. بدون نیاز به جلسهٔ آنلاین، هدف پروژه را بفرستید تا برآورد دقیق دریافت کنید.',
      footerCopy: '© ۲۰۲۶ علیرضا شابان‌زاده',
      footerNote: 'طراح موشن · رشت، ایران · UTC+3:30',
      backToBrand: 'بازگشت به برند',
      showreelModalTitle: 'علیرضا شابان‌زاده — شوریل موشن دیزاین',
      ctaCardTitle: 'پروژهٔ بعدی از شما؟',
      ctaCardSub: 'بگویید موشن باید چه چیزی را نشان دهد تا شرح کار، قیمت و زمان‌بندی دقیق را برایتان بفرستم.',
      ctaCardAction: 'ارسال بریف',
      whyMattersLabel: 'چرا اهمیت دارد و نتیجهٔ کار',
      clientLabel: 'کارفرما',
      deliverableLabel: 'تحویل‌داده‌شده',
      roleLabel: 'نقش من',
      toolsUsedLabel: 'ابزارهای استفاده‌شده',
      galleryItemsLabel: 'آیتم‌های گالری'
    }
  };

  // ==========================================================================
  // 2. REALISTIC FAKE PORTFOLIO DATA (Matching Alireza's real domain)
  // ==========================================================================
  const PORTFOLIO_ITEMS = [
    {
      id: 'idmelon-passkey-suite',
      category: 'ui',
      isBrandCollection: true,
      layout: 'is-wide',
      client: 'IDmelon (Enterprise FIDO2 Security)',
      year: '2025–2026',
      badgeEn: 'Brand Collection · 12 Media Items',
      badgeFa: 'مجموعه برند · ۱۲ فایل رسانه‌ای',
      titleEn: 'Passwordless & Smartphone Security Key Motion Suite',
      titleFa: 'مجموعه موشن‌های کلید امنیتی و احراز هویت بدون رمز IDmelon',
      summaryEn: 'A cohesive library of UI walkthroughs, tap-to-login hardware animations, and enterprise admin dashboard explainers.',
      summaryFa: 'مجموعهٔ یکپارچه از موشن‌های رابط کاربری، انیمیشن‌های ورود با تپ موبایل و راهنمای پنل مدیریت سازمانی.',
      metricValueEn: '-42% Onboarding Tickets',
      metricValueFa: '۴۲٪ کاهش تیکت‌های آموزشی',
      metricLabelEn: 'Deployed across product docs & landing pages',
      metricLabelFa: 'منتشرشده در لندینگ‌پیج‌ها و مستندات فنی',
      cover: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=85',
      video: 'https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-futuristic-devices-99786-large.mp4',
      deliverableEn: '8 UI Loops (WebM/MP4) + 4 Product Explainers',
      deliverableFa: '۸ لوپ رابط کاربری + ۴ ویدیوی اکسپلینر محصول',
      roleEn: 'Lead Motion Designer (Concept, UI Prep, Animation)',
      roleFa: 'طراح ارشد موشن (ایده‌پردازی، بازطراحی UI و انیمیت)',
      tools: ['After Effects', 'Photoshop', 'Illustrator', 'Premiere Pro'],
      whyTextEn: 'Enterprise IT buyers needed to understand within 15 seconds how a smartphone replaces physical FIDO2 hardware keys across Windows and macOS logins.',
      whyTextFa: 'مدیران IT سازمان‌ها باید در کمتر از ۱۵ ثانیه متوجه می‌شدند که چگونه گوشی هوشمند جایگزین توکن‌های سخت‌افزاری FIDO2 برای ورود به ویندوز می‌شود.',
      metrics: [
        { val: '12', labelEn: 'Motion Assets', labelFa: 'فایل موشن' },
        { val: '60fps', labelEn: '4K / WebM Loops', labelFa: 'خروجی 4K / WebM' },
        { val: '3.2x', labelEn: 'Page Engagement', labelFa: 'افزایش تعامل صفحه' }
      ],
      gallery: [
        'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=900&q=80',
        'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=900&q=80',
        'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=900&q=80',
        'https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=900&q=80'
      ]
    },
    {
      id: 'ashna-auth-gateway',
      category: 'ui',
      isBrandCollection: false,
      layout: 'is-compact',
      client: 'Ashna Unified SSO & OTP Platform',
      year: '2026',
      badgeEn: 'Case Study · UI Motion',
      badgeFa: 'مطالعه موردی · موشن رابط کاربری',
      titleEn: 'Smart OTP Failover & Multi-Gateway Routing Flow',
      titleFa: 'نمایش تعاملی مسیریابی هوشمند پیامک OTP و Failover در آشنا',
      summaryEn: 'Visualizing real-time SMS gateway health checks, automatic failover switching, and customizable login widgets.',
      summaryFa: 'تجسم لحظه‌ای بررسی سلامت درگاه‌های پیامک، سوییچ خودکار در زمان اختلال و شخصی‌سازی فرم ورود.',
      metricValueEn: '99.9% Uptime Story',
      metricValueFa: 'نمایش پایداری ۹۹.۹٪',
      metricLabelEn: 'Hero visual for product launch',
      metricLabelFa: 'ویدیوی اصلی کمپین رونمایی محصول',
      cover: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=900&q=85',
      video: 'https://assets.mixkit.co/videos/preview/mixkit-abstract-technology-network-connections-loop-27611-large.mp4',
      deliverableEn: '90s Product Launch Video + 6 Feature Micro-clips',
      deliverableFa: 'ویدیوی ۹۰ ثانیه‌ای معرفی محصول + ۶ کلیپ کوتاه فیچرها',
      roleEn: 'UI Motion Designer & Visual Storyboarder',
      roleFa: 'طراح موشن رابط کاربری و استوری‌بورد',
      tools: ['After Effects', 'Photoshop', 'Figma'],
      whyTextEn: 'Backend reliability is invisible by default. We turned complex API failover logic and rate-limiting rules into an intuitive visual flow that product managers immediately grasped.',
      whyTextFa: 'پایداری زیرساخت بک‌اند معمولاً دیده نمی‌شود؛ با تبدیل منطق سوییچ خودکار درگاه‌ها به یک جریان بصری شفاف، ارزش محصول برای مدیران فنی ملموس شد.',
      metrics: [
        { val: '90s', labelEn: 'Master Explainer', labelFa: 'ویدیوی اصلی' },
        { val: '8', labelEn: 'UI Feature Loops', labelFa: 'لوپ فیچرهای UI' },
        { val: '48h', labelEn: 'Animatic Turnaround', labelFa: 'تحویل انیماتیک' }
      ],
      gallery: [
        'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=900&q=80',
        'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80'
      ]
    },
    {
      id: 'mehr-alborz-elearning',
      category: 'explainer',
      isBrandCollection: false,
      layout: '',
      client: 'Mehr-e-Alborz University',
      year: '2023–2025',
      badgeEn: 'Case Study · E-Learning System',
      badgeFa: 'مطالعه موردی · آموزش الکترونیکی',
      titleEn: 'Modular Visual System for Graduate E-Learning Courses',
      titleFa: 'سیستم بصری و موشن‌های آموزشی دوره‌های کارشناسی ارشد',
      summaryEn: 'Standardized 2D motion templates, animated diagrams, and chapter explainers built to keep online students engaged across 40+ hours of lectures.',
      summaryFa: 'قالب‌های استاندارد موشن دوبعدی، دیاگرام‌های متحرک و اکسپلینرهای سرفصل‌های درسی برای افزایش تمرکز دانشجویان آنلاین.',
      metricValueEn: '120+ Course Modules',
      metricValueFa: '+۱۲۰ ماژول درسی',
      metricLabelEn: '5-year academic production track record',
      metricLabelFa: 'حاصل ۵ سال تولید مستمر محتوای دانشگاهی',
      cover: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1000&q=85',
      video: '',
      deliverableEn: 'Modular AE Template System + 120+ Animated Lectures',
      deliverableFa: 'سیستم قالب‌های ماژولار افترافکتس + بیش از ۱۲۰ جلسه درسی',
      roleEn: 'E-Learning Content Creator & Motion Designer',
      roleFa: 'تولیدکننده محتوای الکترونیکی و طراح موشن',
      tools: ['After Effects', 'Photoshop', 'Premiere Pro', 'Illustrator'],
      whyTextEn: 'Dense academic slides cause rapid learner fatigue. By pacing concepts with progressive visual reveals and clear typography, student completion rates rose significantly.',
      whyTextFa: 'اسلایدهای متنی سنگین باعث خستگی سریع دانشجو می‌شوند. با زمان‌بندی نمایش مفاهیم و استفاده از دیاگرام‌های متحرک، نرخ تکمیل دروس به‌طور چشمگیری افزایش یافت.',
      metrics: [
        { val: '120+', labelEn: 'Modules Delivered', labelFa: 'ماژول تولیدشده' },
        { val: '5 Yrs', labelEn: 'University Tenure', labelFa: 'همکاری مستمر' },
        { val: '1080p', labelEn: 'LMS Optimized', labelFa: 'بهینه برای LMS' }
      ],
      gallery: [
        'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=900&q=80',
        'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=900&q=80'
      ]
    },
    {
      id: 'clexi-brand-gallery',
      category: 'brands',
      isBrandCollection: true,
      layout: '',
      client: 'Clexi Cloud Workspace',
      year: '2025',
      badgeEn: 'Brand Collection · UI & Promo',
      badgeFa: 'مجموعه برند · موشن محصول و تبلیغاتی',
      titleEn: 'Clexi SaaS Onboarding & Micro-Interaction Library',
      titleFa: 'مجموعه انیمیشن‌های آنبوردینگ و تعاملات ریز محصول Clexi',
      summaryEn: 'Clean dark-mode UI motion showcasing collaborative document editing, instant search commands, and team permissions.',
      summaryFa: 'نمایش روان ویرایش هم‌زمان اسناد، جستجوی سریع دستورات و مدیریت دسترسی تیم‌ها در محیط دارک‌مود.',
      metricValueEn: '18s Loop Suite',
      metricValueFa: 'مجموعه لوپ‌های ۱۸ ثانیه‌ای',
      metricLabelEn: 'Zero-layout-shift web embeds',
      metricLabelFa: 'تعبیه در وب بدون افت سرعت صفحه',
      cover: 'https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=1000&q=85',
      video: '',
      deliverableEn: '6 Seamless Product Loops + Brand Styleguide',
      deliverableFa: '۶ لوپ بدون درز محصول + راهنمای حرکت برند',
      roleEn: 'Product Motion Designer',
      roleFa: 'طراح موشن محصول',
      tools: ['After Effects', 'Photoshop'],
      whyTextEn: 'Instead of static screenshots that looked like every other workspace tool, Clexi used lightweight muted video loops to prove speed and polish on first visit.',
      whyTextFa: 'به‌جای اسکرین‌شات‌های ثابت و تکراری، از لوپ‌های ویدیویی سبک استفاده شد تا سرعت و ظرافت محصول در همان نگاه اول به کاربر اثبات شود.',
      metrics: [
        { val: '6', labelEn: 'Feature Loops', labelFa: 'لوپ فیچر' },
        { val: '<1.2MB', labelEn: 'Per WebM Clip', labelFa: 'حجم هر ویدیو' },
        { val: '2 Wks', labelEn: 'Total Delivery', labelFa: 'زمان کل تحویل' }
      ],
      gallery: [
        'https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=900&q=80',
        'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=900&q=80'
      ]
    },
    {
      id: 'tisa-case-showcase',
      category: 'brands',
      isBrandCollection: true,
      layout: 'is-wide',
      client: 'Tisa Case · Custom Hardware & Accessories',
      year: '2025',
      badgeEn: 'Brand Collection · Product Showcase',
      badgeFa: 'مجموعه برند · تیزر و معرفی محصول',
      titleEn: 'Tisa Case Visual Identity & Social Motion Campaign',
      titleFa: 'هویت بصری متحرک و کمپین موشن‌های محصول تیسا کیس',
      summaryEn: 'High-contrast product reveals, kinetic typography, and social-first vertical motion reels highlighting precision print and materials.',
      summaryFa: 'تیزرهای معرفی محصول با کنتراست بالا، تایپوگرافی متحرک و ریلزهای عمودی برای نمایش کیفیت چاپ و متریال.',
      metricValueEn: '4 Multi-Ratio Reels',
      metricValueFa: '۴ ریلز در ابعاد مختلف',
      metricLabelEn: '16:9, 1:1, and 9:16 deliverables',
      metricLabelFa: 'خروجی افقی، مربعی و استوری',
      cover: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=85',
      video: '',
      deliverableEn: '4 Social Campaign Spots + Still Keyframes',
      deliverableFa: '۴ تیزر کمپین شبکه‌های اجتماعی + استایل‌فریم‌ها',
      roleEn: 'Motion Designer & Art Direction',
      roleFa: 'طراح موشن و کارگردان هنری',
      tools: ['After Effects', 'Photoshop', 'Blender'],
      whyTextEn: 'Crafted tactile lighting and snappy rhythmic cuts that stood out immediately in crowded social feeds while keeping the product silhouette front and center.',
      whyTextFa: 'با نورپردازی دقیق و کات‌های ریتمیک، جزئیات متریال محصول در شلوغی فید اینستاگرام و لینکدین به‌سرعت توجه مخاطب را جلب کرد.',
      metrics: [
        { val: '3', labelEn: 'Aspect Ratios', labelFa: 'نسبت تصویر' },
        { val: '15–30s', labelEn: 'Spot Duration', labelFa: 'مدت هر تیزر' },
        { val: '100%', labelEn: 'Async Approval', labelFa: 'تأیید مکتوب' }
      ],
      gallery: [
        'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=900&q=80',
        'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=900&q=80'
      ]
    }
  ];

  // ==========================================================================
  // 3. STATE & DOM REFERENCES
  // ==========================================================================
  let currentLang = 'en';
  let currentFilter = 'all';

  const htmlEl = document.documentElement;
  const headerEl = document.getElementById('header');
  const langToggleBtn = document.getElementById('langToggle');
  const themeToggleBtn = document.getElementById('themeToggle');
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const mobileDrawer = document.getElementById('mobileDrawer');
  const workGrid = document.getElementById('workGrid');
  const workCountBadge = document.getElementById('workCountBadge');
  const filterButtons = document.querySelectorAll('.filter-pill');

  // Hero Reel Elements
  const heroReelVideo = document.getElementById('heroReelVideo');
  const heroReelToggle = document.getElementById('heroReelToggle');
  const heroReelToggleIcon = document.getElementById('heroReelToggleIcon');
  const heroReelToggleText = document.getElementById('heroReelToggleText');
  const openShowreelBtn = document.getElementById('openShowreelBtn');
  const stageFullscreenBtn = document.getElementById('stageFullscreenBtn');

  // Native Dialogs
  const portfolioDialog = document.getElementById('portfolioDialog');
  const dialogKicker = document.getElementById('dialogKicker');
  const dialogTitle = document.getElementById('dialogTitle');
  const dialogMount = document.getElementById('dialogMount');
  const showreelDialog = document.getElementById('showreelDialog');
  const showreelPlayer = document.getElementById('showreelPlayer');

  // ==========================================================================
  // 4. fallback for <dialog closedby="any"> where unsupported (Safari fallback)
  // ==========================================================================
  if (typeof HTMLDialogElement !== 'undefined' && !('closedBy' in HTMLDialogElement.prototype)) {
    const outside = (e, dialog) => {
      const r = dialog.getBoundingClientRect();
      return e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom;
    };
    for (const dialog of document.querySelectorAll('dialog[closedby="any"]')) {
      let pressedOutside = false;
      dialog.addEventListener('pointerdown', (e) => { pressedOutside = outside(e, dialog); });
      dialog.addEventListener('pointerup', (e) => { if (pressedOutside && outside(e, dialog)) dialog.close(); });
    }
  }

  // Pause showreel player when showreel dialog closes
  if (showreelDialog) {
    showreelDialog.addEventListener('close', () => {
      if (showreelPlayer) showreelPlayer.pause();
      showreelDialog.returnValue = '';
    });
  }

  if (portfolioDialog) {
    portfolioDialog.addEventListener('close', () => {
      portfolioDialog.querySelectorAll('video').forEach(v => v.pause());
      portfolioDialog.returnValue = '';
    });
  }

  // ==========================================================================
  // 5. RENDER PORTFOLIO BENTO GRID
  // ==========================================================================
  function renderPortfolio() {
    if (!workGrid) return;
    workGrid.innerHTML = '';

    const dict = I18N[currentLang];
    const filtered = PORTFOLIO_ITEMS.filter(item => {
      if (currentFilter === 'all') return true;
      if (currentFilter === 'brands') return item.isBrandCollection;
      return item.category === currentFilter;
    });

    if (workCountBadge) {
      workCountBadge.textContent = currentLang === 'fa'
        ? `${filtered.length.toLocaleString('fa-IR')} پروژهٔ منتخب`
        : `${filtered.length} Featured Items`;
    }

    filtered.forEach(item => {
      const card = document.createElement('button');
      card.type = 'button';
      card.className = `work-card ${item.layout || ''}`.trim();

      const badgeText = currentLang === 'fa' ? item.badgeFa : item.badgeEn;
      const titleText = currentLang === 'fa' ? item.titleFa : item.titleEn;
      const summaryText = currentLang === 'fa' ? item.summaryFa : item.summaryEn;
      const metricVal = currentLang === 'fa' ? item.metricValueFa : item.metricValueEn;
      const metricLbl = currentLang === 'fa' ? item.metricLabelFa : item.metricLabelEn;

      card.innerHTML = `
        <div class="work-card-media">
          <img src="${item.cover}" alt="${titleText}" class="work-card-img" loading="lazy" decoding="async">
          <div class="work-card-badges">
            <span class="work-pill ${item.isBrandCollection ? 'work-pill-accent' : ''}">${badgeText}</span>
            <span class="work-pill">${item.year}</span>
          </div>
        </div>
        <div class="work-card-body">
          <div>
            <div class="work-card-ClientRow">
              <span>${item.client}</span>
            </div>
            <h3 class="work-card-title">${titleText}</h3>
            <p class="work-card-summary">${summaryText}</p>
          </div>
          <div class="work-card-proof">
            <div class="proof-metric">
              <strong>${metricVal}</strong>
              <span>${metricLbl}</span>
            </div>
            <span class="work-card-arrow" aria-hidden="true">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" class="dir-icon">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
            </span>
          </div>
        </div>
      `;

      card.addEventListener('click', () => openCaseStudyModal(item));
      workGrid.appendChild(card);
    });

    // Append "Your Project Next?" CTA Card
    const ctaCard = document.createElement('a');
    ctaCard.href = '#contact';
    ctaCard.className = 'work-cta-card';
    ctaCard.innerHTML = `
      <span class="work-cta-plus" aria-hidden="true">+</span>
      <h3>${dict.ctaCardTitle}</h3>
      <p>${dict.ctaCardSub}</p>
      <span class="btn btn-primary btn-sm">${dict.ctaCardAction}</span>
    `;
    workGrid.appendChild(ctaCard);
  }

  // ==========================================================================
  // 6. OPEN CASE STUDY / BRAND DIALOG
  // ==========================================================================
  function openCaseStudyModal(item) {
    if (!portfolioDialog || !dialogMount) return;
    const dict = I18N[currentLang];

    const titleText = currentLang === 'fa' ? item.titleFa : item.titleEn;
    const summaryText = currentLang === 'fa' ? item.summaryFa : item.summaryEn;
    const whyText = currentLang === 'fa' ? item.whyTextFa : item.whyTextEn;
    const deliverableText = currentLang === 'fa' ? item.deliverableFa : item.deliverableEn;
    const roleText = currentLang === 'fa' ? item.roleFa : item.roleEn;

    dialogKicker.textContent = `${item.client} · ${item.year}`;
    dialogTitle.textContent = titleText;

    const mediaHtml = item.video
      ? `<video controls autoplay muted loop playsinline poster="${item.cover}">
           <source src="${item.video}" type="video/mp4">
         </video>`
      : `<img src="${item.cover}" alt="${titleText}">`;

    const metricsHtml = (item.metrics || []).map(m => `
      <div class="modal-metric-pill">
        <strong>${m.val}</strong>
        <span>${currentLang === 'fa' ? m.labelFa : m.labelEn}</span>
      </div>
    `).join('');

    const galleryHtml = (item.gallery || []).map((imgUrl, idx) => `
      <div class="modal-gallery-item">
        <img src="${imgUrl}" alt="${titleText} — frame ${idx + 1}" loading="lazy">
      </div>
    `).join('');

    dialogMount.innerHTML = `
      <div class="modal-hero-media">
        ${mediaHtml}
      </div>

      <div class="modal-case-grid">
        <div>
          <p class="modal-case-desc">${summaryText}</p>
          <div class="modal-why-box">
            <h4>${dict.whyMattersLabel}</h4>
            <p>${whyText}</p>
            <div class="modal-metrics-row">
              ${metricsHtml}
            </div>
          </div>
        </div>

        <aside class="modal-facts-card">
          <div class="modal-fact-row">
            <span>${dict.clientLabel}</span>
            <strong>${item.client}</strong>
          </div>
          <div class="modal-fact-row">
            <span>${dict.deliverableLabel}</span>
            <strong>${deliverableText}</strong>
          </div>
          <div class="modal-fact-row">
            <span>${dict.roleLabel}</span>
            <strong>${roleText}</strong>
          </div>
          <div class="modal-fact-row">
            <span>${dict.toolsUsedLabel}</span>
            <strong>${item.tools.join(' · ')}</strong>
          </div>
        </aside>
      </div>

      <div class="modal-gallery-strip">
        ${galleryHtml}
      </div>
    `;

    portfolioDialog.showModal();
  }

  // ==========================================================================
  // 7. LANGUAGE SWITCHER (EN <-> FA with RTL/LTR flip)
  // ==========================================================================
  function applyLanguage(lang) {
    currentLang = lang === 'fa' ? 'fa' : 'en';
    const dict = I18N[currentLang];

    htmlEl.setAttribute('lang', currentLang);
    htmlEl.setAttribute('dir', currentLang === 'fa' ? 'rtl' : 'ltr');

    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (dict[key]) {
        el.setAttribute('placeholder', dict[key]);
      }
    });

    // Update reel button label if paused
    if (heroReelVideo && heroReelToggleText) {
      heroReelToggleText.textContent = heroReelVideo.paused ? dict.playReel : dict.pauseReel;
    }

    renderPortfolio();
  }

  if (langToggleBtn) {
    langToggleBtn.addEventListener('click', () => {
      applyLanguage(currentLang === 'en' ? 'fa' : 'en');
    });
  }

  // ==========================================================================
  // 8. THEME SWITCHER (DARK <-> LIGHT)
  // ==========================================================================
  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const currentTheme = htmlEl.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
      const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
      htmlEl.setAttribute('data-theme', nextTheme);
    });
  }

  // ==========================================================================
  // 9. FILTER PILLS
  // ==========================================================================
  filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      filterButtons.forEach(b => {
        b.classList.remove('is-active');
        b.setAttribute('aria-selected', 'false');
      });
      btn.classList.add('is-active');
      btn.setAttribute('aria-selected', 'true');
      currentFilter = btn.getAttribute('data-filter') || 'all';
      renderPortfolio();
    });
  });

  // ==========================================================================
  // 10. HERO REEL & SHOWREEL MODAL CONTROLS
  // ==========================================================================
  if (heroReelToggle && heroReelVideo) {
    heroReelToggle.addEventListener('click', () => {
      const dict = I18N[currentLang];
      if (heroReelVideo.paused) {
        heroReelVideo.play();
        heroReelToggle.setAttribute('aria-pressed', 'true');
        if (heroReelToggleIcon) heroReelToggleIcon.textContent = '❚❚';
        if (heroReelToggleText) heroReelToggleText.textContent = dict.pauseReel;
      } else {
        heroReelVideo.pause();
        heroReelToggle.setAttribute('aria-pressed', 'false');
        if (heroReelToggleIcon) heroReelToggleIcon.textContent = '▶';
        if (heroReelToggleText) heroReelToggleText.textContent = dict.playReel;
      }
    });
  }

  function openShowreelModal() {
    if (!showreelDialog) return;
    showreelDialog.showModal();
    if (showreelPlayer) {
      showreelPlayer.currentTime = 0;
      showreelPlayer.play().catch(() => {});
    }
  }

  if (openShowreelBtn) openShowreelBtn.addEventListener('click', openShowreelModal);
  if (stageFullscreenBtn) stageFullscreenBtn.addEventListener('click', openShowreelModal);

  // ==========================================================================
  // 11. MOBILE MENU & HEADER SCROLL STATE
  // ==========================================================================
  if (mobileMenuBtn && mobileDrawer) {
    mobileMenuBtn.addEventListener('click', () => {
      const isOpen = !mobileDrawer.hidden;
      mobileDrawer.hidden = isOpen;
      mobileMenuBtn.setAttribute('aria-expanded', String(!isOpen));
    });

    mobileDrawer.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mobileDrawer.hidden = true;
        mobileMenuBtn.setAttribute('aria-expanded', 'false');
      });
    });
  }

  window.addEventListener('scroll', () => {
    if (!headerEl) return;
    headerEl.classList.toggle('is-scrolled', window.scrollY > 24);
  }, { passive: true });

  // ==========================================================================
  // 12. COPY EMAIL & CONTACT FORM DEMO HANDLER
  // ==========================================================================
  const copyEmailBtn = document.getElementById('copyEmailBtn');
  const copyEmailFeedback = document.getElementById('copyEmailFeedback');

  if (copyEmailBtn) {
    copyEmailBtn.addEventListener('click', () => {
      const email = 'hello@alirezashabanzadeh.ir';
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(email).then(() => {
          if (copyEmailFeedback) {
            copyEmailFeedback.textContent = I18N[currentLang].copiedToast;
            setTimeout(() => { copyEmailFeedback.textContent = ''; }, 3000);
          }
        });
      }
    });
  }

  const contactForm = document.getElementById('contactForm');
  const contactStatus = document.getElementById('contactStatus');

  if (contactForm && contactStatus) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('contactName').value.trim();
      const email = document.getElementById('contactEmail').value.trim();
      const message = document.getElementById('contactMessage').value.trim();

      contactStatus.hidden = false;
      if (!name || !email || !message) {
        contactStatus.style.borderColor = '#ef4444';
        contactStatus.style.background = 'rgba(239, 68, 68, 0.12)';
        contactStatus.textContent = currentLang === 'fa'
          ? 'لطفاً نام، ایمیل و متن بریف را کامل وارد کنید.'
          : 'Please fill in your name, email address, and project brief.';
        return;
      }

      contactStatus.style.borderColor = 'rgba(34, 197, 94, 0.45)';
      contactStatus.style.background = 'rgba(34, 197, 94, 0.12)';
      contactStatus.textContent = currentLang === 'fa'
        ? 'بریف شما دریافت شد (دمو)! در نسخهٔ اصلی، پیام به بک‌اند ارسال می‌شود و ظرف ۲۴ ساعت پاسخ دریافت می‌کنید.'
        : 'Brief received (Preview Mode)! In production, this submits to your backend and sends a confirmation.';
      contactForm.reset();
    });
  }

  // Initial render
  renderPortfolio();
})();
